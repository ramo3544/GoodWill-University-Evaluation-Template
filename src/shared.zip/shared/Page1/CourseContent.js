import React, { Component } from 'react';
import CourseContentquest from './CourseContentquest';
import ContentApplicationDevelopmentQ from './ContentApplicationDevelopmentQ';
import OverallCourseContent from './OverallCourseContent';

class CourseContent extends Component {
    render() {
        return (
            <div className="row justify-content-md-center">
                <div className="col-lg-9" style={{marginTop:'30px'}}>
                    <h5>Course Evaluation</h5>
                    <p class="test-justify"> 
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil, 
                        adipisci earum ad laborum qui neque odio optio? 
                        Modi similique perspiciatis nulla tempore ipsum optio? Quas iusto quibusdam quo. Earum, vel?
                    </p>
                    <CourseContentquest/>
                    <ContentApplicationDevelopmentQ/>
                    <OverallCourseContent/>
                </div>
            </div>  
        );
    }
}

export default CourseContent;