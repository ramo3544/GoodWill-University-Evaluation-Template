import React, { Component } from 'react';

class Heading extends Component {
    render() {
        return (
                <div className="row justify-content-md-center">
                    <div className="col-lg-auto">
                        <h1>GWU Course Evaluation</h1>
                        <header className="border-bottom mb-2 pb-9">
                               
                                <div className="progress center-block">
                                       <div className="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="50" style={{width:'33%'}}>33%</div>
                                </div>
                        </header>
                    </div>
                </div>
        );
    }
}

export default Heading;