import React, { Component } from 'react';

class Footer extends Component {
    render() {
        return (
            <div class="row justify-content-between">
                <div class="col-4">
                    <ul class="nav justify-content-center">
                        <li class="nav-item">
                                <a href="GWUStudentinfo.html" class="btn btn-primary btn-lg active" role="button" aria-pressed="true">Back</a>
                        </li>
                    </ul>
                </div>
                <div class="col-4">
                    <ul class="nav justify-content-center">
                        <li class="nav-item">
                            <a href="GWUInstructorEval.html" class="btn btn-primary btn-lg active" role="button" aria-pressed="true">Next</a>
                        </li>
                    </ul>
                </div>
            </div>
        );
    }
}

export default Footer;