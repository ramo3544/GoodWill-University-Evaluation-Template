import React, { Component } from 'react';
import QuestionTemplate from './QuestionTemplate';

class OverallCourseContent extends Component {
    render() {
        return (
            <div class="container">
                <div class="table-responsive-md">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col-md-5"><h5>Overall Course Content</h5> </th>
                                <th scope="col">Strongly Disagree</th>
                                <th scope="col">Disagree</th>
                                <th scope="col">Neutral</th>
                                <th scope="col">Agree</th>
                                <th scope="col">Strongly Agree</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <p><span class="badge badge-primary">Question 1:</span> Lorem ipsum dolor sit amet, consectetur adipisicing elit. </p>
                                </td>  
                                <QuestionTemplate/>                               
                            </tr>
                            <tr>
                                <td>
                                    <p><span class="badge badge-primary">Question 2:</span> Lorem ipsum dolor sit amet, consectetur adipisicing elit. </p>
                                </td>
                                <QuestionTemplate/>
                            </tr>
                            <tr>
                                <td>
                                    <p><span class="badge badge-primary">Question 3:</span> Lorem ipsum dolor sit amet, consectetur adipisicing elit. </p>
                                </td>
                                <QuestionTemplate/>
                            </tr>
                            <tr>
                                <td>
                                    <p><span class="badge badge-primary">Question 4:</span> Lorem ipsum dolor sit amet, consectetur adipisicing elit. </p>
                                </td>
                                <QuestionTemplate/>
                            </tr>
                        </tbody>
                    </table>
                </div>
                {'\n'}
            </div>
        );
    }
}

export default OverallCourseContent;