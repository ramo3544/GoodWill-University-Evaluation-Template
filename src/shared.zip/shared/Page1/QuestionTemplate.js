import React, { Component } from 'react';

class QuestionTemplate extends Component {
    render() {
        return (
            <div>
                <td>
                    <div className="custom-control custom-radio custom-control-inline">
                        <input type="radio" className="custom-control-input" id="defaultGroupExample1" name="groupOfDefaultadios"></input>
                        <label className="custom-control-label" for="defaultGroupExample1"></label>
                    </div>
                </td>
                <td>
                    <div className="custom-control custom-radio custom-control-inline">
                        <input type="radio" className="custom-control-input" id="defaultGroupExample2" name="groupOfDefaultRadios"></input>
                        <label className="custom-control-label" for="defaultGroupExample2"></label>
                    </div>
                </td>
                <td>
                    <div className="custom-control custom-radio custom-control-inline">
                        <input type="radio" className="custom-control-input" id="defaultGroupExample3" name="groupOfDefaultRadios"></input>
                        <label className="custom-control-label" for="defaultGroupExample3"></label>
                    </div>
                </td>
                <td>
                    <div className="custom-control custom-radio custom-control-inline">
                        <input type="radio" className="custom-control-input" id="defaultGroupExample4" name="groupOfDefaultRadios"></input>
                        <label className="custom-control-label" for="defaultGroupExample4"></label>
                    </div>
                </td>
                <td>
                    <div className="custom-control custom-radio custom-control-inline">
                        <input type="radio" className="custom-control-input" id="defaultGroupExample1" name="groupOfDefaultRadios"></input>
                        <label className="custom-control-label" for="defaultGroupExample1"></label>
                    </div>
                </td>                                  
            </div>
        
        );
    }
}

export default QuestionTemplate;