import React, { Component } from 'react';
import NavBar from './NavBar';
import Heading from './Heading';
import Description from './Description';
import Input from './Input';
import BottomNav from './BottomNav';

class StudentInfo extends Component {
    render() {
        return (
            <div>
              <NavBar/>
              <body class="mx-auto">
                <div class="container" style={{paddingTop: '140px', marginLeft: '200px'}}>
                    <Heading/>
                </div>
                <Description/>
                <Input/>
                <BottomNav/>
              </body>
            </div>
        );
    }
}

export default StudentInfo;