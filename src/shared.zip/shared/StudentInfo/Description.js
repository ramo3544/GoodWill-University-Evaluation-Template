import React, { Component } from 'react';

class Description extends Component {
    render() {
        return (
            <div className="row justify-content-md-center">
                <div className="col-sm-8" style={{marginTop: '30px'}}>
                    <h4>Student Information</h4>
                    <p className="test-justify">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil,
                        adipisci earum ad laborum qui neque odio optio? Modi similique
                        perspiciatis nulla tempore ipsum optio? Quas iusto quibusdam quo.
                        Earum, vel?
                    </p>
                </div>  
            </div>
        );
    }
}

export default Description;