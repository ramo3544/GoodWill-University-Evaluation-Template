import React, { Component } from 'react';

class Heading extends Component {
    render() {
        return (
            <div align= "center">
                <h1 style={{fontWeight: 'bold'}}>GOODWILL UNIVERSITY</h1>
                <img src="https://i.imgur.com/xXPpcbV.jpg" title="source: imgur.com" alt = "Error: cannot be rendered"/>
                <h2><p>Thank You</p></h2>
            </div>
        );
    }
}

export default Heading;