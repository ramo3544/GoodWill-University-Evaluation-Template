import React, { Component } from 'react';

class GWULogo extends Component {
    render() {
        return (
            <div className="row justify-content-md-center" style={{paddingLeft: 350, alignItems: 'center', paddingTop: 100}}>
                <div className="col-md-auto">
                        
                    <a href= "https://goodwillsp.org"/>
                        <img src="https://i.imgur.com/xXPpcbV.png" title="source: imgur.com" alt = "Error: cannot be rendered"/>
                    <h1 className="text-center">GWU Course Evaluation</h1>

                </div>
            </div>
        );
    }
}
export default GWULogo;