var express = require('express');
var router = express.Router();
const fs = require('fs');
const path = required('path');

/*Get user listing*/
router.get('/:classid', function())