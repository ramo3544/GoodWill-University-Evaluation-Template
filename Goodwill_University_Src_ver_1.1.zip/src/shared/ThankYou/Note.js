import React, { Component } from 'react';

class Note extends Component {
    render() {
        return (
            <div style={{width:'478px', margin:'0 auto'}}>
                Thank you for taking the time to complete the Course Evaluation.{'\n'} 
                We value your candid feedback and it is essential to our continuous{'\n'} 
                improvement efforts. To Learn more about future courses or if you{'\n'}  
                have any questions, please visit us at missioncode.co.
            </div>
        );
    }
}

export default Note;