import React, { Component } from 'react';

class samplePage extends Component {
    render() {
        return (
            <div style={{marginTop: '100px'}}>
               <h1>Sample Goodwill University HomePage</h1>
               <p>
                   This link would be replaced wiht the Goodwill University Homepage @ https://goodwillsp.org/train/goodwill-university/
                </p> 
            </div>
        );
    }
}

export default samplePage;